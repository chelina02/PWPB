<div class="container">
    <div class="jumbotron mt-4">
    <h1 class="display-4">Welcome To My Website</h1>
    <p class="lead">Hallo Nama Saya <?= $data['nama']; ?></p>
     <hr class="my-4">
     <p> semua yang pergi pasti akan kembali, entah pada hati yang sama ataupun pada hati yang lain</p>
     <a class="btn btn-primary btn-lg" href="#" role="button">Selengkapnya</a>
     </div>
</div>