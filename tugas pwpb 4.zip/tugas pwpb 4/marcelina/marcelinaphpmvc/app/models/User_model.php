<?php

class User_model {
    private $nama = 'MARCELINA PUTRI CIPTHA DEWI';

    public function  getUser()
    {
        return $this->nama;
    }
}  